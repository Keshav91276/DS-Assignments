#include<iostream>
#include<stack>

using namespace std;

int priority(char ch){
    if(ch=='(') return 0;
    else if(ch=='+'||'-') return 1;
    else if(ch=='*'||'/') return 2;

    return -1;
    
}

void infixToPostfix(string exp){
    stack<char> str;
    char x;
    int i=0;
    while(i<exp.size()){
        if(isalnum(exp[i])) cout<<exp[i];

        else if(exp[i]=='(') str.push(exp[i]);
        
        else if (exp[i] == ')') {
            
            while (!str.empty() && str.top() != '(') {
                cout << str.top();
                str.pop();
            }
            if(!str.empty()) str.pop();  // remove '('
        }

        else{
            while(!str.empty()&&priority(str.top())>=priority(exp[i])){
                cout<<str.top();
                str.pop();
            }
            str.push(exp[i]);

        }

        i++;

    }

    

    while(!str.empty()){
        cout<<str.top();
        str.pop();
    }
    cout<<endl;

}

int main(){
    string exp;
    cout<<"Enter the expression"<<endl;
    getline(cin,exp);
    cout<<"The postfix expression will be:"<<endl;
    infixToPostfix(exp);

    return 0;
}