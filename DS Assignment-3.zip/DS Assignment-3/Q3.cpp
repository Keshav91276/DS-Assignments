#include<iostream>

using namespace std;

bool balanceParenth(string str){

    stack<char> check;
    for(int i=0;i<str.size();i++){
        if(str[i]=='(') check.push('(');

        else if(str[i]==')') check.pop();
    }

    if(check.empty()) return true;
    else return false;
}

int main(){
string str;
    cout<<"Enter the string"<<endl;
    getline(cin,str);

    bool balanced=balanceParenth(str);
    (balanced==true?cout<<"The expression has balanced parenthesis":cout<<"The expression doesn't have balanced parenthesis");

    return 0;
}