#include<iostream>
#include<stack>
using namespace std;

const int MAX=10;
void addElement(stack<int> &st){
    int element;
    cout<<"Enter the element you want to add "<<endl;
    cin>>element;

    st.push(element);
    
}

void removeElement(stack<int> &st){
    st.pop();

}

void checkEmpty(stack<int> st){
    if(st.empty()) cout<<"It's an empty stack"<<endl;
    else cout<<"It's not an empty stack"<<endl;

}    
void checkFull(stack<int> st){
if(st.size()==MAX) cout<<"The stack is full"<<endl;
            
else cout<<"The stack is not full"<<endl;
    
}

void display(stack<int> st){
 while(!st.empty()){
    cout<<st.top()<<endl;
    st.pop();
 }
}

void topElement(stack<int> st){
    cout<<"The top element is "<<st.top()<<endl;

}

int main(){
    stack<int> st;
    st.push(1);
    st.push(2);
    st.push(3);
    st.push(4);
    st.push(5);
    st.push(6);
    st.push(7);
    st.push(8);
    st.push(9);
    st.push(10);
    int input;
    cout<<"Enter your desired operation"<<endl;
    cout<<"1.Add an element\n "<<"2.Remove an element\n "<<"3.Check whether the stack is empty or not\n "<<"4.Check whether the stack is full or not\n "<<"5.Display the elements of the stack\n "<<"6.Check the top element "<<endl;
    cin>>input;

    switch(input){
        case 1:
        addElement(st);
        break;

        case 2:
        removeElement(st);
        break;

        case 3:
        checkEmpty(st);
        break;

        case 4:
        checkFull(st);
        break;

        case 5:
        display(st);
        break;

        case 6:
        topElement(st);
        break;

    
    }

    return 0;
    
}
