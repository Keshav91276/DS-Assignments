#include<iostream>
#include<stack>
#include<string>

using namespace std;

int main(){
stack<char> ch;
string str;
cout<<"Enter the string"<<endl;
getline(cin,str);

for(int i=0;i<str.size();i++){

    ch.push(str[i]);
}

cout<<"The reversed string is "<<endl;

while(!ch.empty()){
    cout<<ch.top();
    ch.pop();
}

return 0;



}