#include<iostream>

using namespace std;

int evaluatePostfix(string str){
stack<int> st;

for(int i=0;i<str.size();i++){
    char ch=str[i];
    if(ch==' ') continue;

    if(isdigit(ch)) st.push(ch-'0');

    else{
        int val2=st.top(); st.pop();
        int val1=st.top(); st.pop();

        switch(ch){
            case '+': st.push(val1+val2); break;
            case '-': st.push(val1-val2); break;
            case '*': st.push(val1*val2); break;
            case '/': st.push(val1/val2); break;
        }
    }
}

return st.top();

}

int main(){

    string str;
    cout<<"Enter the postfix expression you want to evaluate"<<endl;
    getline(cin,str);

    cout<<"The evaluated result is: "<<evaluatePostfix(str);

    

    return 0;
}